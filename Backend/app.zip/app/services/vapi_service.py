from __future__ import annotations

import hashlib
import hmac
import json
from datetime import UTC, datetime
from time import time
from typing import cast

import structlog
from fastapi import BackgroundTasks, HTTPException, status
from sqlalchemy import Select, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.config import Settings
from app.models.assessment_report import AssessmentReport
from app.models.assessment_session import AssessmentSession
from app.models.webhook_event import WebhookEvent
from app.schemas.enums import PassFail, ReportStatus, SessionStatus, VapiCallEndReason
from app.schemas.webhook import (
    VapiAnalysisDone,
    VapiCallEnded,
    VapiCallStarted,
    VapiTranscriptMessage,
    VapiTranscriptUpdate,
)
from app.services.anthropic_service import trigger_report_generation_background

logger = structlog.get_logger(__name__)
SIGNATURE_TOLERANCE_SECONDS = 300


def validate_vapi_signature(payload: bytes, signature_header: str, secret: str) -> None:
    signature_parts = _parse_signature_header(signature_header)
    timestamp = signature_parts.get("t")
    received_signature = signature_parts.get("v1")

    if timestamp is None or received_signature is None:
        raise _invalid_signature()

    try:
        timestamp_seconds = int(timestamp)
    except ValueError as exc:
        raise _invalid_signature() from exc

    now_seconds = int(time())
    if abs(now_seconds - timestamp_seconds) > SIGNATURE_TOLERANCE_SECONDS:
        raise _invalid_signature()

    signed_payload = timestamp.encode("utf-8") + b"." + payload
    expected_signature = hmac.new(
        secret.encode("utf-8"),
        signed_payload,
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_signature, received_signature):
        raise _invalid_signature()


def validate_vapi_webhook_auth(
    payload: bytes,
    signature_header: str,
    shared_secret_header: str,
    secret: str,
) -> None:
    if signature_header.strip() != "":
        validate_vapi_signature(payload, signature_header, secret)
        return

    if shared_secret_header.strip() == "":
        raise _invalid_signature()

    if not hmac.compare_digest(shared_secret_header, secret):
        raise _invalid_signature()


async def handle_call_started(db: AsyncSession, event: VapiCallStarted) -> None:
    session = await _get_session_by_call_id(db, event.call_id)
    session.status = SessionStatus.IN_PROGRESS
    session.started_at = event.started_at
    logger.info(
        "vapi_call_started_processed",
        session_id=str(session.id),
        call_id=event.call_id,
        assistant_id=event.assistant_id,
    )


async def handle_call_ended(db: AsyncSession, event: VapiCallEnded) -> None:
    session = await _get_session_by_call_id(db, event.call_id)
    session.status = (
        SessionStatus.FAILED if event.end_reason == VapiCallEndReason.ERROR else SessionStatus.COMPLETED
    )
    session.ended_at = event.ended_at
    session.duration_seconds = event.duration_seconds
    logger.info(
        "vapi_call_ended_processed",
        session_id=str(session.id),
        call_id=event.call_id,
        end_reason=event.end_reason.value,
        status=session.status.value,
    )


async def handle_transcript_update(db: AsyncSession, event: VapiTranscriptUpdate) -> None:
    session = await _get_session_by_call_id(db, event.call_id)
    existing_transcript = _load_transcript(session.raw_transcript)
    incoming_transcript = [_transcript_message_to_dict(message) for message in event.transcript]
    merged_transcript = _merge_transcript(existing_transcript, incoming_transcript)
    session.raw_transcript = json.dumps(merged_transcript, ensure_ascii=False, separators=(",", ":"))
    logger.info(
        "vapi_transcript_update_processed",
        session_id=str(session.id),
        call_id=event.call_id,
        transcript_items=len(merged_transcript),
    )


async def handle_analysis_done(
    db: AsyncSession,
    event: VapiAnalysisDone,
    background_tasks: BackgroundTasks,
    settings: Settings,
    session_factory: async_sessionmaker[AsyncSession],
) -> None:
    session = await _get_session_by_call_id(db, event.call_id)
    session.vapi_analysis = {
        "summary": event.summary,
        "structured_data": event.structured_data,
        "received_at": datetime.now(UTC).isoformat(),
    }
    await _ensure_pending_report(db, session)
    background_tasks.add_task(
        trigger_report_generation_background,
        session.id,
        session_factory,
        settings,
    )
    logger.info(
        "vapi_analysis_done_processed",
        session_id=str(session.id),
        call_id=event.call_id,
    )


async def get_or_create_webhook_event(
    db: AsyncSession,
    event_id: str,
    event_type: str,
    payload: dict[str, object],
) -> tuple[WebhookEvent, bool]:
    try:
        insert_statement = (
            insert(WebhookEvent)
            .values(
                event_type=event_type,
                vapi_event_id=event_id,
                payload=payload,
            )
            .on_conflict_do_nothing(index_elements=[WebhookEvent.vapi_event_id])
            .returning(WebhookEvent.id)
        )
        insert_result = await db.execute(insert_statement)
        inserted_id = insert_result.scalar_one_or_none()

        query: Select[tuple[WebhookEvent]] = (
            select(WebhookEvent)
            .where(
                WebhookEvent.vapi_event_id == event_id,
                WebhookEvent.deleted_at.is_(None),
            )
            .with_for_update()
        )
        select_result = await db.execute(query)
        webhook_event = select_result.scalar_one_or_none()
    except SQLAlchemyError as exc:
        logger.exception(
            "webhook_event_get_or_create_failed",
            vapi_event_id=event_id,
            event_type=event_type,
            error=str(exc),
        )
        raise

    if webhook_event is None:
        raise LookupError(f"webhook_event_not_found:{event_id}")

    return webhook_event, inserted_id is not None


async def _ensure_pending_report(db: AsyncSession, session: AssessmentSession) -> None:
    try:
        query: Select[tuple[AssessmentReport]] = (
            select(AssessmentReport)
            .where(
                AssessmentReport.session_id == session.id,
                AssessmentReport.deleted_at.is_(None),
            )
            .with_for_update()
        )
        result = await db.execute(query)
        report = result.scalar_one_or_none()
    except SQLAlchemyError as exc:
        logger.exception("vapi_pending_report_lookup_failed", session_id=str(session.id), error=str(exc))
        raise

    if report is not None:
        if report.generation_status in {ReportStatus.FAILED, ReportStatus.PENDING}:
            report.generation_status = ReportStatus.PENDING
            report.generation_error = None
        return

    db.add(
        AssessmentReport(
            session_id=session.id,
            version=1,
            overall_score=None,
            pass_fail=PassFail.INCONCLUSIVE,
            strengths=[],
            weaknesses=[],
            detailed_analysis="Report generation has not completed.",
            recommendations="Report generation has not completed.",
            anthropic_model_used="pending",
            anthropic_prompt_tokens=0,
            anthropic_completion_tokens=0,
            generation_status=ReportStatus.PENDING,
        )
    )


def _parse_signature_header(signature_header: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for part in signature_header.split(","):
        key, separator, value = part.strip().partition("=")
        if separator == "=" and key and value:
            parsed[key] = value
    return parsed


def _invalid_signature() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="invalid_signature",
    )


async def _get_session_by_call_id(db: AsyncSession, call_id: str) -> AssessmentSession:
    try:
        query: Select[tuple[AssessmentSession]] = (
            select(AssessmentSession)
            .where(
                AssessmentSession.vapi_call_id == call_id,
                AssessmentSession.deleted_at.is_(None),
            )
            .with_for_update()
        )
        result = await db.execute(query)
        session = result.scalar_one_or_none()
    except SQLAlchemyError as exc:
        logger.exception("vapi_session_lookup_failed", call_id=call_id, error=str(exc))
        raise

    if session is None:
        raise LookupError(f"assessment_session_not_found_for_call:{call_id}")
    return session


def _load_transcript(raw_transcript: str | None) -> list[dict[str, object]]:
    if raw_transcript is None or raw_transcript.strip() == "":
        return []

    decoded = json.loads(raw_transcript)
    if not isinstance(decoded, list):
        raise ValueError("raw_transcript_must_be_json_array")

    transcript: list[dict[str, object]] = []
    for item in decoded:
        if not isinstance(item, dict):
            raise ValueError("raw_transcript_item_must_be_object")
        transcript.append(cast(dict[str, object], item))
    return transcript


def _transcript_message_to_dict(message: VapiTranscriptMessage) -> dict[str, object]:
    dumped = message.model_dump(mode="json")
    return cast(dict[str, object], dumped)


def _merge_transcript(
    existing: list[dict[str, object]],
    incoming: list[dict[str, object]],
) -> list[dict[str, object]]:
    merged_by_key: dict[tuple[str, str, float], dict[str, object]] = {}
    for item in [*existing, *incoming]:
        role = item.get("role")
        content = item.get("content")
        timestamp = item.get("timestamp")
        if not isinstance(role, str) or not isinstance(content, str):
            raise ValueError("transcript_item_role_and_content_must_be_strings")
        if not isinstance(timestamp, int | float):
            raise ValueError("transcript_item_timestamp_must_be_number")
        merged_by_key[(role, content, float(timestamp))] = {
            "role": role,
            "content": content,
            "timestamp": float(timestamp),
        }
    return sorted(merged_by_key.values(), key=lambda item: cast(float, item["timestamp"]))
